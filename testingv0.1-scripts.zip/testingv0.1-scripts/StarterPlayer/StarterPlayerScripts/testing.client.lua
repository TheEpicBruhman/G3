--[[
    testing (LocalScript)
    Path: StarterPlayer → StarterPlayerScripts
    Parent: StarterPlayerScripts
    Properties:
        Disabled: false
    Exported: 2026-08-19 06:16:26 (web)
]]

--Get Service

const GeometryService = game:GetService("GeometryService")
local replicatedFirst = game:GetService("ReplicatedFirst")
const RunService = game:GetService("RunService")

--Get Module data

local g3 = require(replicatedFirst.G3)

--Main code

local rand1 = Random.new():NextNumber()
local rand2 = Random.new():NextNumber()
local rand3 = Random.new():NextNumber()
local testP = 3
local d = 0
local test2 = {}
local layer1: g3.gui
local layer2
local layer3: g3.gui
local part: g3.part

workspace:WaitForChild("Part")

--[[
local test = 3
for i = 1, test do
	layer1 = g3.NewGui("layer1")
	for j = 1, test do
		layer2 = g3.NewGui("layer2")
			layer2.Parent = layer1
		for k = 1, test do
			layer3 = g3.NewGui("layer3")
			for l = 1, 100 do
				d += 1
				part = g3.NewPartToGui(layer3, "part" .. d)
					rand1 = Random.new():NextNumber()
					rand2 = Random.new():NextNumber()
					rand3 = Random.new():NextNumber()
					part.Position = Vector2.new(rand1, rand2) * 5 - Vector2.new(2.5, 2.5)
					part.Offset = rand3 + 4
					--part.Part.Transparency = 0.7
					part.Rotation = Vector3.new(rand1 * 36, rand2 * 36, rand3 * 90)
			end
			layer3.Parent = layer2
			layer3.Offset = 15
			layer3.Position = Vector2.new(Random.new():NextNumber() * 20 - 10, Random.new():NextNumber() * 20 - 10)
		end
	end
end
--]]
--[[
local gui = g3.NewGui("test")
gui.Offset = 5
local part = g3.NewPartToGui(gui, "test")
part.Size = UDim2.fromScale(0.5, 0.5)
local part2 = g3.NewPartToGui(gui, "test2")
part2.Offset = 1.5
part2.Size = UDim2.fromScale(0.7, 0.7)
part2.Part.Color = Color3.new(1, 0, 0)
]]
--local icon = g3.FromModel(workspace["g3 icon"])
--icon.Rotation = Vector3.new(15, 15, 0)
--testPart:VelocityIterative({Offset = 10})


--if true then return end

local model = workspace.superman

workspace:WaitForChild("superman")



--test:VelocityIterative({Offset = 1})
--
local gui = g3.NewGui("test")
gui.Offset = 5
local part = g3.NewPartToGui(gui, "test")
part.Position = Vector2.new(0, -1.5)
part.Offset = 1
local part2 = g3.NewPartToGui(gui, "test2")
part2.Position = Vector2.new(0, -2)
part2.Offset = 1
--]]
task.wait(0.02)
g3.MergeParts(part, {part2})

