--[[
    TODO (LocalScript)
    Path: ReplicatedStorage
    Parent: ReplicatedStorage
    Properties:
        Disabled: false
    Exported: 2026-08-19 06:16:26 (web)
]]

--TODO: Make G3 animator module, fix screen safe size scaling